export interface Post {
  id:String;
  title:String;
  content:String;
  imagePath:string;
  creator:string;
}
