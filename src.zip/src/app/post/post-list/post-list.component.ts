import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import {Subscription} from "rxjs";
import {Post} from '../post.model';
import { PostsService } from '../posts.service';
import { PageEvent } from '@angular/material';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'app-post-list',
  templateUrl: './post-list.component.html',
  styleUrls: ['./post-list.component.css']
})
export class PostListComponent implements OnInit, OnDestroy {
  /*posts = [
    {title:"First Post", content:"This is my first post "},
    {title:"Second post", content:"This is second post"},
    {title:"Third Post", content:"This is Third post"}
  ]*/
  posts:Post[] = [];
  isLoading= false;
  totalPosts=0;
  postsPerPage = 2;
  currentPage = 1;
  pageSizeOptions = [1,2,5,10];
  private postSubscription:Subscription;
  private authStatusSub:Subscription;
  userIsAuthenticated=false;
  userId:string;
  constructor(public postsService:PostsService, public authservice:AuthService) { }

  ngOnInit() {
    this.isLoading = true;
     this.postsService.getPosts(this.postsPerPage,this.currentPage);
     this.userId = this.authservice.getUserId();
    this.postSubscription=this.postsService.getupdatedListener()
    .subscribe((postData:{posts:Post[],postCount:number}) => {
      this.isLoading=false;
      this.posts = postData.posts;
      this.userId = this.authservice.getUserId();
      this.totalPosts = postData.postCount;
    });
  this.userIsAuthenticated = this.authservice.getIsAuth();
    this.authStatusSub = this.authservice.getAuthStatusListener().subscribe(isAuthenticated => {
     this.userIsAuthenticated = isAuthenticated;
    })
  }

onChangedPage(pageData: PageEvent){
  console.log(pageData);
  this.isLoading = true;
  this.currentPage = pageData.pageIndex +1;
  this.postsPerPage = pageData.pageSize;

  this.postsService.getPosts(this.postsPerPage,this.currentPage);
}


  onDelete(postId:string){
    console.log(postId);
    this.isLoading=true;
  this.postsService.deletePost(postId).subscribe(
    () => {
      this.postsService.getPosts(this.postsPerPage,this.currentPage)
    }, () => {
    this.isLoading = false;
    }
  );
  }

  ngOnDestroy(){
    this.postSubscription.unsubscribe();
  }

}
