const express = require('express');

const route = express.Router();
const checkAuth = require('../middleware/check-auth');
const postController = require('../controller/post');
const extractFile = require('../middleware/files');
const { createShorthandPropertyAssignment } = require('typescript');
//5f169b4f580bdf3dec8eb88c

route.post("",checkAuth,extractFile,postController.createPost);

route.get("",postController.getPosts);

route.put("/:id",checkAuth,extractFile,postController.updatePost);

route.get("/:id",postController.getPost);

route.delete('/:id',checkAuth,postController.deletePost);
module.exports = route;
