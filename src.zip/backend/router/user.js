const express = require('express');

const User = require('../models/user');
const user = require('../models/user');
const userController = require('../controller/user');
const router = express.Router();

router.post("/signup",userController.createUser);

router.post("/login",userController.login);

module.exports = router;
