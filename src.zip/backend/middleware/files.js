const multer = require('multer');

const MIME_TYPE_MAP = {
  'image/png':'png',
  'image/jpeg':'jpg',
  'image/jpg':'jpg'
}

const storage = multer.diskStorage({
  destination:(req,file,cb) => {
  const isValid = MIME_TYPE_MAP[file.mimetype];
  console.log(isValid);

  let error = new Error("its not required mime type");
  if(!isValid){
    error = null;
  }

  cb(null,"backend/images");
  },
  filename:(req,file,cb) => {
  const name = file.originalname.toLowerCase().split(" ").join("-");
  console.log(file.mimetype +"test");
  console.log(MIME_TYPE_MAP[(file.mimetype).toString()]);
  const ext = MIME_TYPE_MAP[file.mimetype];
  console.log(ext+"ext");
  cb(null,name+"-"+Date.now()+"."+ext);
  }
});

module.exports= multer({storage:storage}).single("image");
