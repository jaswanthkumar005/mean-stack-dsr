const path = require("path");
const express = require("express");
const bodyParser =require('body-parser');
const mongoose = require('mongoose');
const { ModuleResolutionKind } = require("typescript");
const Post = require('./models/post');
const postRoute = require('./router/posts');
const userRoute = require('./router/user');

const app = express();
console.log(process.env);
mongoose.connect("mongodb://127.0.0.1:27017/Node-Angular-api")
.then(() => {
  console.log('connected to database');
}).catch((error) =>{
  console.log(error,'connection failed');
});
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
app.use("/images",express.static(path.join("backend/images")));
app.use((req,res,next) => {
  res.setHeader("Access-Control-Allow-Origin","*");
  res.setHeader("Access-Control-Allow-Headers","Origin, X-Requested-With, Content-Type, Accept,Authorization");
  res.setHeader("Access-Control-Allow-Methods","GET, POST, PATCH, DELETE, OPTIONS, PUT")
  next();
});

app.use("/api/posts",postRoute);
app.use('/api/user',userRoute);

module.exports=app;
