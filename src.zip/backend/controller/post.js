const Post = require('../models/post');
exports.createPost = (req,res,next)=> {
  const url = req.protocol+"://"+req.get("host");
  const post = new Post({
  title: req.body.title,
  content:req.body.content,
  imagePath:url+"/images/"+req.file.filename,
  creator:req.userData.userId
  });

  post.save().then(result => {
    console.log(result)
    res.status(201).json({
      message:"post added successfully",
      post:{
        ...result,
        id:result._id
      }
    });
  }).catch(
    error =>{
      res.status(500).json({
        message:"creating post failed"
      })
    }
  );
};

exports.updatePost = (req,res,next) => {
  console.log(req.file);
  let imagePath = req.body.imagePath;
  if(req.file){
    const url = req.protocol + "://" + req.get("host");
    imagePath = url + "/images/" + req.file.filename;
  }
  const post = new Post({
    _id:req.body.id,
    title:req.body.title,
    content:req.body.content,
    imagePath:imagePath
  })
  Post.updateOne({_id:req.params.id,creator:req.userData.userId},post).then(result => {
   console.log(result);
   if(result.n > 0){
     res.status(200).json({message:"Updated Successfully!"});
   } else{
     res.status(401).json({message:"Not Authorized to update"});
   }

 })
 .catch(error => {
   res.status(500).json({
     message:"could nt update post"
   });
 });
};

exports.getPost= (req,res,next) => {
  Post.findById(req.params.id).then(post =>  {
    if(post){
      res.status(200).json(post);

    } else {
      res.status(404).json({message:'post not found'});
    }
  }).catch(error => {
    res.status(500).json({
      message:"Fetching post failed!"
    })
  });

};

exports.getPosts = (req,res,next)=>{

  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;
  console.log(pageSize,currentPage,"test pagiatio");
  const postQuery = Post.find();
  let fecthedPosts;
  if(pageSize && currentPage){
    postQuery.skip(pageSize * (currentPage-1))
    .limit(pageSize);
  }
  postQuery.then((documents) => {

    fecthedPosts = documents;
    return Post.count();
  })
  .then(count => {
   res.status(200).json({
     message:"Post fecthed successfully",
     posts:fecthedPosts,
     maxPosts:count

   })
  })
  .catch(error => {
    res.status(500).json({
      message:"Fetching posts failed!"
    });
  });

    /*
    res.status(200).json({
      message:"posted fetched successfully",
      posts:documents
    }); */

  };

  exports.deletePost = (req,res,next) => {
    console.log(req.params.id);
    Post.deleteOne({_id:req.params.id, creator:req.userData.userId}).then((result) =>{
      console.log(result,"mongoose delete");
      if(result.n >0){
        res.status(200).json({
          message:"Post Deleted",
          postId:result._id
        });
      } else {
        res.status(401).json({
          message:"Not authorised to delteed",
          postId:result._id
        });
      }

    }).catch(error => {
     res.status(500).json({
       message:"deleting failed"
     });
    });

  };
